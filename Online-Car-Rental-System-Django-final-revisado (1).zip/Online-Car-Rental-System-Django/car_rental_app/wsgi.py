"""Configuração WSGI do projeto."""
import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "car_rental_app.settings")

application = get_wsgi_application()
